// src/pages/Analytics.js
import React from 'react'
import Chart from '../components/Chart'

const Analytics = () => {
  return (
    <div>
      <h2>Analytics</h2>
      <Chart />
    </div>
  )
}

export default Analytics
